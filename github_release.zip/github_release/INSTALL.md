# 🚀 SUPER EASY INSTALLATION GUIDE
*No technical knowledge required!*

## Step 1: Get Python (if you don't have it)
1. Go to https://python.org/downloads
2. Click the big "Download Python" button
3. Run the installer
4. **IMPORTANT**: Check "Add Python to PATH" during installation

## Step 2: Download Venom Scanner
1. Download this folder to your computer
2. Put it somewhere easy to find (like Desktop or Documents)

## Step 3: Run the Auto-Setup
**EASIEST WAY:**
- Double-click the `setup.py` file
- Follow the instructions on screen
- That's it! The setup does everything for you.

**If double-clicking doesn't work:**
1. Open Command Prompt (Windows) or Terminal (Mac/Linux)
2. Navigate to the venom folder: `cd path/to/venom`
3. Run: `python setup.py`

## Step 4: Start Scanning!

After setup is complete, you can use the scanner in 3 easy ways:

### Method 1: Double-Click (Easiest)
- **Windows**: Double-click `venom.bat`
- **Mac/Linux**: Double-click `venom.sh`

### Method 2: Command Line
```bash
python main.py -t google.com
```

### Method 3: With Options
```bash
# Basic scan
python main.py -t example.com

# Save results to file
python main.py -t example.com -o my_results.txt

# Faster scanning (more threads)
python main.py -t example.com --threads 50

# Get all details
python main.py -t example.com --verbose
```

## 🎯 What Does This Tool Do?

**Venom Scanner** finds subdomains that could be "taken over" by attackers. Here's what that means in simple terms:

- **Subdomains** = things like `blog.yoursite.com`, `api.yoursite.com`
- **Takeover** = when an attacker can control these subdomains
- **Why it matters** = They could serve malicious content or steal data

The tool checks for:
- Abandoned cloud services (AWS S3, GitHub Pages, etc.)
- Misconfigured DNS records
- Services that are no longer active but still pointed to

## 📋 Example Output

```
🚨 VULNERABLE SUBDOMAINS FOUND:
[1] old-blog.example.com
    Status: VULNERABLE
    Service: github_pages
    Confidence: HIGH
    CNAME: olduser.github.io
    ⚠️  POTENTIAL SUBDOMAIN TAKEOVER VULNERABILITY
```

## ⚠️ IMPORTANT LEGAL NOTE

**ONLY scan domains you own or have explicit permission to test!**

- This is a security tool for legitimate testing
- Scanning others' domains without permission may be illegal
- Use responsibly and ethically

## 🆘 Need Help?

**Setup Issues:**
1. Make sure Python is installed correctly
2. Try running `python --version` to check
3. On some systems, use `python3` instead of `python`

**Scanning Issues:**
- Make sure you own the domain you're testing
- Check your internet connection
- Try with `--verbose` flag for more details

**Common Commands:**
```bash
# See all options
python main.py --help

# Test the tool works
python main.py -t google.com --check-cname-only

# Quick scan (fewer subdomains)
python main.py -t example.com --threads 10

# Detailed scan with all info
python main.py -t example.com --verbose
```

## 🎉 You're Ready!

Once setup is complete, you can:
- ✅ Scan any domain you own
- ✅ Save results in different formats (JSON, CSV, TXT)
- ✅ Customize the scanning speed and options
- ✅ Find potential security vulnerabilities

**Remember**: Use this tool responsibly and only on domains you control!
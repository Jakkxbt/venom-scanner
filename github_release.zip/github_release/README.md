# Venom Vulnerability Scanner

A comprehensive subdomain takeover vulnerability scanner that detects misconfigured DNS records and services vulnerable to subdomain takeover attacks.

## 🚀 Features

- **Comprehensive Scanning**: Detects vulnerabilities across multiple cloud services and platforms
- **DNS Analysis**: Performs thorough DNS resolution and CNAME record analysis
- **HTTP Fingerprinting**: Analyzes HTTP responses for vulnerability indicators
- **Multi-threaded**: Fast scanning with configurable thread counts
- **Multiple Output Formats**: Export results in JSON, CSV, or text formats
- **Colored Output**: Easy-to-read results with color-coded vulnerability indicators
- **Rate Limiting**: Configurable delays to avoid overwhelming target servers
- **Progress Tracking**: Real-time progress indicators during scanning

## 🎯 Supported Services

Venom can detect subdomain takeover vulnerabilities for the following services:

- Amazon S3 (AWS)
- GitHub Pages
- Heroku
- Netlify
- Surge.sh
- Firebase
- Microsoft Azure
- Shopify
- Tumblr
- WordPress.com
- Fastly
- Pantheon
- Bitbucket
- And more...

## 📋 Requirements

- Python 3.6 or higher
- Required Python packages:
  - `requests`
  - `dnspython`
  - `colorama`

## 🛠️ Installation

### Method 1: Direct Installation

1. Clone or download this repository
2. Install required dependencies:
   ```bash
   pip install requests dnspython colorama
   ```
3. Run the scanner:
   ```bash
   python main.py -t example.com
   ```

### Method 2: Create Standalone Executable

1. Install PyInstaller:
   ```bash
   pip install pyinstaller requests dnspython colorama
   ```

2. Run the build script:
   ```bash
   python build.py
   ```

3. Find the executable in the `dist` directory

## 📚 Usage

### Basic Usage

```bash
# Scan a domain
python main.py -t example.com

# Scan with custom wordlist
python main.py -t example.com -w custom_wordlist.txt

# Save results to file
python main.py -t example.com -o results.json --format json

# Increase thread count for faster scanning
python main.py -t example.com --threads 50

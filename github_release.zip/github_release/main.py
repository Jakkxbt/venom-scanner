#!/usr/bin/env python3
"""
Venom Vulnerability Scanner - Subdomain Takeover Detection Tool
A comprehensive scanner for detecting subdomain takeover vulnerabilities.
"""

import argparse
import sys
import os
import json
from colorama import init, Fore, Style
from scanner.core import VenomScanner
from scanner.utils import validate_url, print_banner

# Initialize colorama for cross-platform colored output
init(autoreset=True)

def main():
    """Main entry point for the Venom vulnerability scanner."""
    
    # Print banner
    print_banner()
    
    # Set up argument parser
    parser = argparse.ArgumentParser(
        description="Venom - Subdomain Takeover Vulnerability Scanner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py -t example.com
  python main.py -t example.com -w wordlists/custom.txt
  python main.py -t example.com -o results.json --format json
  python main.py -t example.com -o results.csv --format csv --threads 50
        """
    )
    
    # Required arguments
    parser.add_argument(
        '-t', '--target',
        type=str,
        required=True,
        help='Target domain to scan (e.g., example.com)'
    )
    
    # Optional arguments
    parser.add_argument(
        '-w', '--wordlist',
        type=str,
        default='wordlists/subdomains.txt',
        help='Path to subdomain wordlist (default: wordlists/subdomains.txt)'
    )
    
    parser.add_argument(
        '-o', '--output',
        type=str,
        help='Output file path for results'
    )
    
    parser.add_argument(
        '--format',
        choices=['json', 'csv', 'txt'],
        default='txt',
        help='Output format (default: txt)'
    )
    
    parser.add_argument(
        '--threads',
        type=int,
        default=20,
        help='Number of threads to use (default: 20)'
    )
    
    parser.add_argument(
        '--timeout',
        type=int,
        default=10,
        help='HTTP request timeout in seconds (default: 10)'
    )
    
    parser.add_argument(
        '--dns-timeout',
        type=int,
        default=5,
        help='DNS resolution timeout in seconds (default: 5)'
    )
    
    parser.add_argument(
        '--delay',
        type=float,
        default=0.1,
        help='Delay between requests in seconds (default: 0.1)'
    )
    
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose output'
    )
    
    parser.add_argument(
        '--no-color',
        action='store_true',
        help='Disable colored output'
    )
    
    parser.add_argument(
        '--check-cname-only',
        action='store_true',
        help='Only check CNAME records, skip HTTP requests'
    )
    
    # Parse arguments
    args = parser.parse_args()
    
    # Validate target URL
    if not validate_url(args.target):
        print(f"{Fore.RED}[ERROR] Invalid target domain: {args.target}{Style.RESET_ALL}")
        sys.exit(1)
    
    # Check if wordlist exists
    if not os.path.exists(args.wordlist):
        print(f"{Fore.RED}[ERROR] Wordlist file not found: {args.wordlist}{Style.RESET_ALL}")
        sys.exit(1)
    
    # Initialize scanner
    try:
        scanner = VenomScanner(
            target=args.target,
            wordlist=args.wordlist,
            threads=args.threads,
            timeout=args.timeout,
            dns_timeout=args.dns_timeout,
            delay=args.delay,
            verbose=args.verbose,
            no_color=args.no_color,
            check_cname_only=args.check_cname_only
        )
        
        print(f"{Fore.CYAN}[INFO] Starting scan of {args.target}")
        print(f"[INFO] Using {args.threads} threads with {args.delay}s delay")
        print(f"[INFO] Timeout settings: HTTP={args.timeout}s, DNS={args.dns_timeout}s{Style.RESET_ALL}")
        print()
        
        # Run the scan
        results = scanner.run()
        
        # Display results
        scanner.display_results(results)
        
        # Export results if output file specified
        if args.output:
            success = scanner.export_results(results, args.output, args.format)
            if success:
                print(f"\n{Fore.GREEN}[SUCCESS] Results exported to {args.output}{Style.RESET_ALL}")
            else:
                print(f"\n{Fore.RED}[ERROR] Failed to export results{Style.RESET_ALL}")
        
        # Print summary
        vulnerable_count = len([r for r in results if r.get('vulnerable', False)])
        total_checked = len(results)
        
        print(f"\n{Fore.CYAN}[SUMMARY] Checked {total_checked} subdomains")
        if vulnerable_count > 0:
            print(f"[SUMMARY] Found {vulnerable_count} potential vulnerabilities{Style.RESET_ALL}")
        else:
            print(f"[SUMMARY] No vulnerabilities found{Style.RESET_ALL}")
            
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}[INFO] Scan interrupted by user{Style.RESET_ALL}")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Fore.RED}[ERROR] An unexpected error occurred: {str(e)}{Style.RESET_ALL}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()

"""
Venom Vulnerability Scanner Package
"""

__version__ = "1.0.0"
__author__ = "Venom Security Team"
__description__ = "Subdomain Takeover Vulnerability Scanner"

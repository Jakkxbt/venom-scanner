"""
Core scanner functionality for Venom vulnerability scanner.
"""

import threading
import time
import queue
from concurrent.futures import ThreadPoolExecutor, as_completed
from colorama import Fore, Style
from .dns_resolver import DNSResolver
from .subdomain_discovery import SubdomainDiscovery
from .vulnerability_checks import VulnerabilityChecker
from .report_generator import ReportGenerator
from .utils import print_progress, is_valid_subdomain

class VenomScanner:
    """Main scanner class that orchestrates the subdomain takeover detection."""
    
    def __init__(self, target, wordlist, threads=20, timeout=10, dns_timeout=5, 
                 delay=0.1, verbose=False, no_color=False, check_cname_only=False):
        """
        Initialize the Venom scanner.
        
        Args:
            target (str): Target domain to scan
            wordlist (str): Path to subdomain wordlist
            threads (int): Number of threads to use
            timeout (int): HTTP request timeout
            dns_timeout (int): DNS resolution timeout
            delay (float): Delay between requests
            verbose (bool): Enable verbose output
            no_color (bool): Disable colored output
            check_cname_only (bool): Only check CNAME records
        """
        self.target = target.lower().strip()
        self.wordlist = wordlist
        self.threads = threads
        self.timeout = timeout
        self.dns_timeout = dns_timeout
        self.delay = delay
        self.verbose = verbose
        self.no_color = no_color
        self.check_cname_only = check_cname_only
        
        # Initialize components
        self.dns_resolver = DNSResolver(timeout=dns_timeout)
        self.subdomain_discovery = SubdomainDiscovery(wordlist)
        self.vulnerability_checker = VulnerabilityChecker(timeout=timeout)
        self.report_generator = ReportGenerator()
        
        # Thread-safe counters and locks
        self.lock = threading.Lock()
        self.checked_count = 0
        self.total_count = 0
        self.start_time = None
        
    def run(self):
        """
        Run the complete vulnerability scan.
        
        Returns:
            list: List of scan results
        """
        self.start_time = time.time()
        
        # Step 1: Discover subdomains
        print(f"{Fore.YELLOW}[STEP 1] Discovering subdomains...{Style.RESET_ALL}")
        subdomains = self.subdomain_discovery.generate_subdomains(self.target)
        self.total_count = len(subdomains)
        
        if self.verbose:
            print(f"[DEBUG] Generated {self.total_count} subdomain combinations")
        
        # Step 2: Scan subdomains
        print(f"{Fore.YELLOW}[STEP 2] Scanning subdomains for vulnerabilities...{Style.RESET_ALL}")
        results = self._scan_subdomains(subdomains)
        
        # Step 3: Filter and sort results
        filtered_results = self._filter_results(results)
        
        return filtered_results
    
    def _scan_subdomains(self, subdomains):
        """
        Scan a list of subdomains for vulnerabilities using threading.
        
        Args:
            subdomains (list): List of subdomains to scan
            
        Returns:
            list: List of scan results
        """
        results = []
        results_lock = threading.Lock()
        
        def scan_subdomain(subdomain):
            """Scan a single subdomain."""
            try:
                # Add delay for rate limiting
                if self.delay > 0:
                    time.sleep(self.delay)
                
                result = self._check_subdomain(subdomain)
                
                with results_lock:
                    if result:
                        results.append(result)
                
                # Update progress
                with self.lock:
                    self.checked_count += 1
                    if not self.no_color:
                        print_progress(self.checked_count, self.total_count, subdomain)
                
            except Exception as e:
                if self.verbose:
                    print(f"\n[ERROR] Error scanning {subdomain}: {str(e)}")
        
        # Use ThreadPoolExecutor for concurrent scanning
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            # Submit all tasks
            futures = [executor.submit(scan_subdomain, subdomain) for subdomain in subdomains]
            
            # Wait for all tasks to complete
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as e:
                    if self.verbose:
                        print(f"\n[ERROR] Thread error: {str(e)}")
        
        print()  # New line after progress
        return results
    
    def _check_subdomain(self, subdomain):
        """
        Check a single subdomain for vulnerabilities.
        
        Args:
            subdomain (str): Subdomain to check
            
        Returns:
            dict: Scan result or None if not vulnerable/interesting
        """
        if not is_valid_subdomain(subdomain):
            return None
        
        result = {
            'subdomain': subdomain,
            'vulnerable': False,
            'service': None,
            'cname': None,
            'ip_addresses': [],
            'http_status': None,
            'http_response': None,
            'error_message': None,
            'confidence': 'low',
            'timestamp': time.time()
        }
        
        try:
            # Step 1: DNS Resolution
            dns_info = self.dns_resolver.resolve_subdomain(subdomain)
            
            if not dns_info:
                return None  # No DNS records found
            
            result.update(dns_info)
            
            # Step 2: Check CNAME for known vulnerable services
            if result['cname']:
                vuln_result = self.vulnerability_checker.check_cname_vulnerability(result['cname'])
                if vuln_result:
                    result.update(vuln_result)
                    result['vulnerable'] = True
            
            # Step 3: HTTP checks (unless CNAME-only mode)
            if not self.check_cname_only and result['ip_addresses']:
                http_result = self.vulnerability_checker.check_http_vulnerability(subdomain)
                if http_result:
                    result.update(http_result)
                    if http_result.get('vulnerable', False):
                        result['vulnerable'] = True
            
            # Only return results that are potentially interesting
            if result['vulnerable'] or result['cname'] or self.verbose:
                return result
                
        except Exception as e:
            if self.verbose:
                print(f"\n[DEBUG] Error checking {subdomain}: {str(e)}")
        
        return None
    
    def _filter_results(self, results):
        """
        Filter and sort scan results.
        
        Args:
            results (list): Raw scan results
            
        Returns:
            list: Filtered and sorted results
        """
        # Sort by vulnerability status and confidence
        def sort_key(result):
            vulnerability_score = 3 if result['vulnerable'] else 0
            confidence_scores = {'high': 3, 'medium': 2, 'low': 1}
            confidence_score = confidence_scores.get(result.get('confidence', 'low'), 1)
            return (vulnerability_score, confidence_score, result['subdomain'])
        
        return sorted(results, key=sort_key, reverse=True)
    
    def display_results(self, results):
        """
        Display scan results in a formatted way.
        
        Args:
            results (list): Scan results to display
        """
        if not results:
            print(f"{Fore.GREEN}[INFO] No subdomains found or no vulnerabilities detected{Style.RESET_ALL}")
            return
        
        print(f"{Fore.CYAN}[RESULTS] Scan completed in {time.time() - self.start_time:.2f} seconds{Style.RESET_ALL}")
        print("=" * 80)
        
        vulnerable_results = [r for r in results if r.get('vulnerable', False)]
        interesting_results = [r for r in results if not r.get('vulnerable', False)]
        
        # Display vulnerable results first
        if vulnerable_results:
            print(f"\n{Fore.RED}🚨 VULNERABLE SUBDOMAINS FOUND:{Style.RESET_ALL}")
            for i, result in enumerate(vulnerable_results, 1):
                self._display_result(result, i, vulnerable=True)
        
        # Display interesting but not confirmed vulnerable results
        if interesting_results and self.verbose:
            print(f"\n{Fore.YELLOW}📋 INTERESTING SUBDOMAINS:{Style.RESET_ALL}")
            for i, result in enumerate(interesting_results, 1):
                self._display_result(result, i, vulnerable=False)
    
    def _display_result(self, result, index, vulnerable=False):
        """
        Display a single scan result.
        
        Args:
            result (dict): Scan result to display
            index (int): Result index number
            vulnerable (bool): Whether this is a vulnerable result
        """
        status_color = Fore.RED if vulnerable else Fore.YELLOW
        subdomain = result['subdomain']
        
        print(f"\n{status_color}[{index}] {subdomain}{Style.RESET_ALL}")
        
        if result.get('cname'):
            print(f"    CNAME: {result['cname']}")
        
        if result.get('ip_addresses'):
            ips = ', '.join(result['ip_addresses'])
            print(f"    IP(s): {ips}")
        
        if result.get('service'):
            print(f"    Service: {result['service']}")
        
        if result.get('http_status'):
            print(f"    HTTP Status: {result['http_status']}")
        
        if result.get('error_message'):
            print(f"    Error: {result['error_message']}")
        
        if result.get('confidence'):
            confidence_color = {
                'high': Fore.RED,
                'medium': Fore.YELLOW,
                'low': Fore.CYAN
            }.get(result['confidence'], Fore.WHITE)
            print(f"    Confidence: {confidence_color}{result['confidence'].upper()}{Style.RESET_ALL}")
        
        if vulnerable:
            print(f"    {Fore.RED}⚠️  POTENTIAL SUBDOMAIN TAKEOVER VULNERABILITY{Style.RESET_ALL}")
    
    def export_results(self, results, output_path, format_type):
        """
        Export scan results to file.
        
        Args:
            results (list): Scan results to export
            output_path (str): Output file path
            format_type (str): Export format (json, csv, txt)
            
        Returns:
            bool: True if export successful, False otherwise
        """
        try:
            return self.report_generator.export_results(results, output_path, format_type)
        except Exception as e:
            if self.verbose:
                print(f"[ERROR] Export failed: {str(e)}")
            return False

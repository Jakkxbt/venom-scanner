"""
DNS resolution functionality for the Venom scanner.
"""

import socket
import dns.resolver
import dns.exception
from .utils import extract_domain

class DNSResolver:
    """Handle DNS resolution operations."""
    
    def __init__(self, timeout=5):
        """
        Initialize DNS resolver.
        
        Args:
            timeout (int): DNS query timeout in seconds
        """
        self.timeout = timeout
        self.resolver = dns.resolver.Resolver()
        self.resolver.timeout = timeout
        self.resolver.lifetime = timeout
    
    def resolve_subdomain(self, subdomain):
        """
        Resolve DNS records for a subdomain.
        
        Args:
            subdomain (str): Subdomain to resolve
            
        Returns:
            dict: DNS resolution results or None if no records found
        """
        result = {
            'cname': None,
            'ip_addresses': [],
            'mx_records': [],
            'txt_records': []
        }
        
        try:
            # Try to resolve A records
            try:
                answers = self.resolver.resolve(subdomain, 'A')
                result['ip_addresses'] = [str(answer) for answer in answers]
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
                pass
            
            # Try to resolve AAAA records (IPv6)
            try:
                answers = self.resolver.resolve(subdomain, 'AAAA')
                ipv6_addresses = [str(answer) for answer in answers]
                result['ip_addresses'].extend(ipv6_addresses)
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
                pass
            
            # Try to resolve CNAME records
            try:
                answers = self.resolver.resolve(subdomain, 'CNAME')
                if answers:
                    result['cname'] = str(answers[0]).rstrip('.')
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
                pass
            
            # Try to resolve MX records
            try:
                answers = self.resolver.resolve(subdomain, 'MX')
                result['mx_records'] = [str(answer) for answer in answers]
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
                pass
            
            # Try to resolve TXT records
            try:
                answers = self.resolver.resolve(subdomain, 'TXT')
                result['txt_records'] = [str(answer).strip('"') for answer in answers]
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
                pass
            
        except Exception as e:
            # Return None for any major DNS errors
            return None
        
        # Return result if we found any DNS records
        if result['ip_addresses'] or result['cname'] or result['mx_records']:
            return result
        
        return None
    
    def reverse_dns_lookup(self, ip_address):
        """
        Perform reverse DNS lookup.
        
        Args:
            ip_address (str): IP address to lookup
            
        Returns:
            str: Hostname or None if lookup fails
        """
        try:
            hostname = socket.gethostbyaddr(ip_address)[0]
            return hostname
        except (socket.herror, socket.gaierror):
            return None
    
    def check_dns_propagation(self, subdomain, record_type='A'):
        """
        Check if DNS records are properly propagated.
        
        Args:
            subdomain (str): Subdomain to check
            record_type (str): DNS record type to check
            
        Returns:
            bool: True if records are propagated, False otherwise
        """
        try:
            answers = self.resolver.resolve(subdomain, record_type)
            return len(answers) > 0
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
            return False
    
    def get_nameservers(self, domain):
        """
        Get nameservers for a domain.
        
        Args:
            domain (str): Domain to check
            
        Returns:
            list: List of nameservers
        """
        try:
            answers = self.resolver.resolve(domain, 'NS')
            return [str(answer).rstrip('.') for answer in answers]
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
            return []
    
    def check_wildcard_dns(self, domain):
        """
        Check if domain has wildcard DNS configured.
        
        Args:
            domain (str): Domain to check
            
        Returns:
            bool: True if wildcard DNS is configured
        """
        # Test with a random subdomain that shouldn't exist
        import random
        import string
        
        random_subdomain = ''.join(random.choices(string.ascii_lowercase, k=20))
        test_domain = f"{random_subdomain}.{domain}"
        
        try:
            answers = self.resolver.resolve(test_domain, 'A')
            return len(answers) > 0
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.DNSException):
            return False

"""
Report generation functionality for the Venom scanner.
"""

import json
import csv
import time
from datetime import datetime
from .utils import format_timestamp

class ReportGenerator:
    """Handle report generation in various formats."""
    
    def __init__(self):
        """Initialize report generator."""
        pass
    
    def export_results(self, results, output_path, format_type):
        """
        Export scan results to specified format.
        
        Args:
            results (list): Scan results to export
            output_path (str): Output file path
            format_type (str): Export format (json, csv, txt)
            
        Returns:
            bool: True if export successful, False otherwise
        """
        try:
            if format_type.lower() == 'json':
                return self._export_json(results, output_path)
            elif format_type.lower() == 'csv':
                return self._export_csv(results, output_path)
            elif format_type.lower() == 'txt':
                return self._export_txt(results, output_path)
            else:
                print(f"[ERROR] Unsupported format: {format_type}")
                return False
        except Exception as e:
            print(f"[ERROR] Export failed: {str(e)}")
            return False
    
    def _export_json(self, results, output_path):
        """
        Export results to JSON format.
        
        Args:
            results (list): Scan results
            output_path (str): Output file path
            
        Returns:
            bool: True if successful
        """
        # Prepare data for JSON export
        export_data = {
            'scan_info': {
                'tool': 'Venom Vulnerability Scanner',
                'version': '1.0.0',
                'timestamp': datetime.now().isoformat(),
                'total_results': len(results),
                'vulnerable_count': len([r for r in results if r.get('vulnerable', False)])
            },
            'results': []
        }
        
        for result in results:
            # Clean up result for JSON serialization
            clean_result = {}
            for key, value in result.items():
                if key == 'timestamp':
                    clean_result[key] = format_timestamp(value)
                else:
                    clean_result[key] = value
            
            export_data['results'].append(clean_result)
        
        # Write to file
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
        
        return True
    
    def _export_csv(self, results, output_path):
        """
        Export results to CSV format.
        
        Args:
            results (list): Scan results
            output_path (str): Output file path
            
        Returns:
            bool: True if successful
        """
        if not results:
            return False
        
        # Define CSV columns
        columns = [
            'subdomain',
            'vulnerable',
            'service',
            'confidence',
            'cname',
            'ip_addresses',
            'http_status',
            'error_message',
            'timestamp'
        ]
        
        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=columns)
            writer.writeheader()
            
            for result in results:
                # Prepare row data
                row = {}
                for col in columns:
                    value = result.get(col, '')
                    
                    # Handle special formatting
                    if col == 'ip_addresses' and isinstance(value, list):
                        row[col] = ', '.join(value)
                    elif col == 'timestamp' and value:
                        row[col] = format_timestamp(value)
                    elif col == 'vulnerable':
                        row[col] = 'Yes' if value else 'No'
                    else:
                        row[col] = str(value) if value is not None else ''
                
                writer.writerow(row)
        
        return True
    
    def _export_txt(self, results, output_path):
        """
        Export results to text format.
        
        Args:
            results (list): Scan results
            output_path (str): Output file path
            
        Returns:
            bool: True if successful
        """
        with open(output_path, 'w', encoding='utf-8') as f:
            # Write header
            f.write("VENOM VULNERABILITY SCANNER - SCAN RESULTS\n")
            f.write("=" * 60 + "\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total Results: {len(results)}\n")
            
            vulnerable_count = len([r for r in results if r.get('vulnerable', False)])
            f.write(f"Vulnerable: {vulnerable_count}\n")
            f.write("\n")
            
            if not results:
                f.write("No results found.\n")
                return True
            
            # Separate vulnerable and non-vulnerable results
            vulnerable_results = [r for r in results if r.get('vulnerable', False)]
            other_results = [r for r in results if not r.get('vulnerable', False)]
            
            # Write vulnerable results first
            if vulnerable_results:
                f.write("VULNERABLE SUBDOMAINS:\n")
                f.write("-" * 40 + "\n")
                
                for i, result in enumerate(vulnerable_results, 1):
                    f.write(f"\n[{i}] {result['subdomain']}\n")
                    f.write(f"    Status: VULNERABLE\n")
                    
                    if result.get('service'):
                        f.write(f"    Service: {result['service']}\n")
                    
                    if result.get('confidence'):
                        f.write(f"    Confidence: {result['confidence'].upper()}\n")
                    
                    if result.get('cname'):
                        f.write(f"    CNAME: {result['cname']}\n")
                    
                    if result.get('ip_addresses'):
                        ips = ', '.join(result['ip_addresses'])
                        f.write(f"    IP(s): {ips}\n")
                    
                    if result.get('http_status'):
                        f.write(f"    HTTP Status: {result['http_status']}\n")
                    
                    if result.get('error_message'):
                        f.write(f"    Error: {result['error_message']}\n")
                    
                    if result.get('timestamp'):
                        f.write(f"    Checked: {format_timestamp(result['timestamp'])}\n")
            
            # Write other interesting results
            if other_results:
                f.write(f"\n\nOTHER INTERESTING SUBDOMAINS:\n")
                f.write("-" * 40 + "\n")
                
                for i, result in enumerate(other_results, 1):
                    f.write(f"\n[{i}] {result['subdomain']}\n")
                    f.write(f"    Status: NOT VULNERABLE\n")
                    
                    if result.get('cname'):
                        f.write(f"    CNAME: {result['cname']}\n")
                    
                    if result.get('ip_addresses'):
                        ips = ', '.join(result['ip_addresses'])
                        f.write(f"    IP(s): {ips}\n")
                    
                    if result.get('http_status'):
                        f.write(f"    HTTP Status: {result['http_status']}\n")
        
        return True
    
    def generate_summary_report(self, results):
        """
        Generate a summary report of scan results.
        
        Args:
            results (list): Scan results
            
        Returns:
            dict: Summary report data
        """
        summary = {
            'total_checked': len(results),
            'vulnerable_count': 0,
            'services_found': {},
            'confidence_distribution': {'high': 0, 'medium': 0, 'low': 0},
            'common_errors': {},
            'ip_ranges': set(),
            'cname_services': set()
        }
        
        for result in results:
            # Count vulnerabilities
            if result.get('vulnerable', False):
                summary['vulnerable_count'] += 1
            
            # Track services
            service = result.get('service')
            if service:
                summary['services_found'][service] = summary['services_found'].get(service, 0) + 1
            
            # Track confidence levels
            confidence = result.get('confidence', 'low')
            summary['confidence_distribution'][confidence] = summary['confidence_distribution'].get(confidence, 0) + 1
            
            # Track common errors
            error = result.get('error_message')
            if error:
                summary['common_errors'][error] = summary['common_errors'].get(error, 0) + 1
            
            # Track IP ranges
            ips = result.get('ip_addresses', [])
            for ip in ips:
                # Extract first two octets for IP range analysis
                if '.' in ip:
                    range_prefix = '.'.join(ip.split('.')[:2])
                    summary['ip_ranges'].add(range_prefix)
            
            # Track CNAME services
            cname = result.get('cname')
            if cname:
                # Extract service from CNAME
                if '.amazonaws.com' in cname:
                    summary['cname_services'].add('AWS')
                elif '.github.io' in cname or '.githubusercontent.com' in cname:
                    summary['cname_services'].add('GitHub')
                elif '.herokuapp.com' in cname:
                    summary['cname_services'].add('Heroku')
                elif '.netlify.com' in cname:
                    summary['cname_services'].add('Netlify')
                # Add more service detection as needed
        
        # Convert sets to lists for JSON serialization
        summary['ip_ranges'] = list(summary['ip_ranges'])
        summary['cname_services'] = list(summary['cname_services'])
        
        return summary
    
    def create_html_report(self, results, output_path):
        """
        Create an HTML report (basic implementation).
        
        Args:
            results (list): Scan results
            output_path (str): Output HTML file path
            
        Returns:
            bool: True if successful
        """
        try:
            html_template = """
<!DOCTYPE html>
<html>
<head>
    <title>Venom Scanner Results</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background: #f0f0f0; padding: 15px; border-radius: 5px; }
        .vulnerable { color: #d32f2f; font-weight: bold; }
        .safe { color: #388e3c; }
        .result { margin: 10px 0; padding: 10px; border: 1px solid #ddd; border-radius: 3px; }
        .details { margin-left: 20px; font-size: 0.9em; color: #666; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Venom Vulnerability Scanner Results</h1>
        <p>Generated: {timestamp}</p>
        <p>Total Results: {total_results}</p>
        <p>Vulnerabilities Found: {vulnerable_count}</p>
    </div>
    
    <h2>Results</h2>
    {results_html}
</body>
</html>
            """
            
            # Generate results HTML
            results_html = ""
            for result in results:
                status_class = "vulnerable" if result.get('vulnerable', False) else "safe"
                status_text = "VULNERABLE" if result.get('vulnerable', False) else "Safe"
                
                results_html += f"""
                <div class="result">
                    <strong>{result['subdomain']}</strong> 
                    <span class="{status_class}">[{status_text}]</span>
                    <div class="details">
                """
                
                if result.get('service'):
                    results_html += f"Service: {result['service']}<br>"
                if result.get('confidence'):
                    results_html += f"Confidence: {result['confidence']}<br>"
                if result.get('cname'):
                    results_html += f"CNAME: {result['cname']}<br>"
                if result.get('ip_addresses'):
                    ips = ', '.join(result['ip_addresses'])
                    results_html += f"IP(s): {ips}<br>"
                if result.get('error_message'):
                    results_html += f"Error: {result['error_message']}<br>"
                
                results_html += "</div></div>"
            
            # Fill template
            html_content = html_template.format(
                timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                total_results=len(results),
                vulnerable_count=len([r for r in results if r.get('vulnerable', False)]),
                results_html=results_html
            )
            
            # Write to file
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            return True
            
        except Exception as e:
            print(f"[ERROR] HTML report generation failed: {str(e)}")
            return False

"""
Subdomain discovery functionality for the Venom scanner.
"""

import os
from .utils import is_valid_subdomain

class SubdomainDiscovery:
    """Handle subdomain discovery and generation."""
    
    def __init__(self, wordlist_path):
        """
        Initialize subdomain discovery.
        
        Args:
            wordlist_path (str): Path to subdomain wordlist file
        """
        self.wordlist_path = wordlist_path
        self.wordlist = self._load_wordlist()
    
    def _load_wordlist(self):
        """
        Load subdomain wordlist from file.
        
        Returns:
            list: List of subdomain prefixes
        """
        wordlist = []
        
        try:
            with open(self.wordlist_path, 'r', encoding='utf-8') as f:
                for line in f:
                    word = line.strip().lower()
                    if word and not word.startswith('#'):
                        wordlist.append(word)
        except FileNotFoundError:
            print(f"[ERROR] Wordlist file not found: {self.wordlist_path}")
            # Use default wordlist if file not found
            wordlist = self._get_default_wordlist()
        except Exception as e:
            print(f"[ERROR] Error loading wordlist: {str(e)}")
            wordlist = self._get_default_wordlist()
        
        return list(set(wordlist))  # Remove duplicates
    
    def _get_default_wordlist(self):
        """
        Get default subdomain wordlist if file is not available.
        
        Returns:
            list: Default subdomain prefixes
        """
        return [
            'www', 'mail', 'ftp', 'localhost', 'webmail', 'smtp', 'pop', 'ns1', 'webdisk',
            'ns2', 'cpanel', 'whm', 'autodiscover', 'autoconfig', 'wpad', 'm', 'mobile',
            'w3', 'owa', 'remote', 'exchange', 'blog', 'vpn', 'direct-connect-mail',
            'direct', 'mail2', 'gw', 'proxy', 'ads', 'mail3', 'folder', 'admanager',
            'aspnet_client', 'docs', 'calvin', 'clientaccesspolicy', 'webconf', 'sh',
            'sftp', 'ftp2', 'relay', 'iphone', 'admin', 'emails', 'test', 'api',
            'dev', 'staging', 'beta', 'demo', 'support', 'help', 'status', 'shop',
            'store', 'cms', 'crm', 'forum', 'community', 'portal', 'secure', 'ssl',
            'git', 'svn', 'repo', 'repository', 'code', 'cdn', 'static', 'assets',
            'media', 'uploads', 'files', 'download', 'downloads', 'img', 'images',
            'video', 'videos', 'live', 'stream', 'radio', 'tv', 'news', 'press',
            'careers', 'jobs', 'hr', 'recruitment', 'login', 'signin', 'signup',
            'register', 'auth', 'sso', 'oauth', 'openid', 'ldap', 'ad', 'directory',
            'search', 'find', 'locate', 'map', 'maps', 'gis', 'geo', 'location',
            'tracking', 'analytics', 'stats', 'statistics', 'metrics', 'monitor',
            'monitoring', 'health', 'ping', 'uptime', 'status', 'nagios', 'zabbix'
        ]
    
    def generate_subdomains(self, domain):
        """
        Generate list of subdomains to test.
        
        Args:
            domain (str): Base domain
            
        Returns:
            list: List of subdomains to test
        """
        subdomains = []
        
        # Generate subdomains from wordlist
        for word in self.wordlist:
            subdomain = f"{word}.{domain}"
            if is_valid_subdomain(subdomain):
                subdomains.append(subdomain)
        
        # Add some additional patterns
        additional_patterns = self._generate_additional_patterns(domain)
        subdomains.extend(additional_patterns)
        
        # Remove duplicates and sort
        return sorted(list(set(subdomains)))
    
    def _generate_additional_patterns(self, domain):
        """
        Generate additional subdomain patterns.
        
        Args:
            domain (str): Base domain
            
        Returns:
            list: Additional subdomain patterns
        """
        patterns = []
        
        # Common numbered patterns
        for i in range(1, 11):
            patterns.extend([
                f"www{i}.{domain}",
                f"mail{i}.{domain}",
                f"ftp{i}.{domain}",
                f"ns{i}.{domain}",
                f"mx{i}.{domain}",
                f"smtp{i}.{domain}",
                f"pop{i}.{domain}",
                f"imap{i}.{domain}"
            ])
        
        # Environment-based patterns
        environments = ['dev', 'test', 'staging', 'prod', 'production', 'demo', 'beta', 'alpha']
        services = ['api', 'app', 'web', 'www', 'admin', 'portal', 'dashboard']
        
        for env in environments:
            patterns.append(f"{env}.{domain}")
            for service in services:
                patterns.extend([
                    f"{env}-{service}.{domain}",
                    f"{service}-{env}.{domain}",
                    f"{env}{service}.{domain}"
                ])
        
        # Regional patterns
        regions = ['us', 'eu', 'asia', 'uk', 'ca', 'au', 'de', 'fr', 'jp', 'cn']
        for region in regions:
            patterns.extend([
                f"{region}.{domain}",
                f"www-{region}.{domain}",
                f"api-{region}.{domain}"
            ])
        
        # Cloud service patterns
        cloud_patterns = [
            f"s3.{domain}",
            f"cdn.{domain}",
            f"bucket.{domain}",
            f"storage.{domain}",
            f"files.{domain}",
            f"assets.{domain}",
            f"media.{domain}",
            f"static.{domain}"
        ]
        patterns.extend(cloud_patterns)
        
        # Filter valid subdomains
        valid_patterns = [p for p in patterns if is_valid_subdomain(p)]
        
        return valid_patterns
    
    def add_custom_wordlist(self, custom_words):
        """
        Add custom words to the wordlist.
        
        Args:
            custom_words (list): List of custom subdomain prefixes
        """
        self.wordlist.extend(custom_words)
        self.wordlist = list(set(self.wordlist))  # Remove duplicates
    
    def filter_by_length(self, max_length=63):
        """
        Filter wordlist by maximum subdomain length.
        
        Args:
            max_length (int): Maximum allowed subdomain length
        """
        self.wordlist = [word for word in self.wordlist if len(word) <= max_length]
    
    def get_wordlist_stats(self):
        """
        Get statistics about the loaded wordlist.
        
        Returns:
            dict: Wordlist statistics
        """
        if not self.wordlist:
            return {'count': 0, 'avg_length': 0, 'max_length': 0, 'min_length': 0}
        
        lengths = [len(word) for word in self.wordlist]
        
        return {
            'count': len(self.wordlist),
            'avg_length': sum(lengths) / len(lengths),
            'max_length': max(lengths),
            'min_length': min(lengths)
        }

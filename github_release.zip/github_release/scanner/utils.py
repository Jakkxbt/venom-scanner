"""
Utility functions for the Venom scanner.
"""

import re
import sys
import time
from datetime import datetime
from urllib.parse import urlparse
from colorama import Fore, Style

def validate_url(url):
    """
    Validate if the input is a valid domain/URL.
    
    Args:
        url (str): URL or domain to validate
        
    Returns:
        bool: True if valid, False otherwise
    """
    # Remove protocol if present
    if url.startswith(('http://', 'https://')):
        parsed = urlparse(url)
        domain = parsed.netloc
    else:
        domain = url
    
    # Basic domain validation
    domain_pattern = re.compile(
        r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
    )
    
    return bool(domain_pattern.match(domain))

def is_valid_subdomain(subdomain):
    """
    Check if a subdomain is valid according to RFC standards.
    
    Args:
        subdomain (str): Subdomain to validate
        
    Returns:
        bool: True if valid, False otherwise
    """
    if not subdomain or len(subdomain) > 253:
        return False
    
    # Check each label
    labels = subdomain.split('.')
    for label in labels:
        if not label or len(label) > 63:
            return False
        
        # Label must start and end with alphanumeric
        if not re.match(r'^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$', label):
            return False
    
    return True

def extract_domain(url):
    """
    Extract domain from URL.
    
    Args:
        url (str): URL to extract domain from
        
    Returns:
        str: Extracted domain
    """
    if url.startswith(('http://', 'https://')):
        parsed = urlparse(url)
        return parsed.netloc
    return url

def print_banner():
    """Print the Venom scanner banner."""
    banner = f"""
{Fore.GREEN}
██╗   ██╗███████╗███╗   ██╗ ██████╗ ███╗   ███╗
██║   ██║██╔════╝████╗  ██║██╔═══██╗████╗ ████║
██║   ██║█████╗  ██╔██╗ ██║██║   ██║██╔████╔██║
╚██╗ ██╔╝██╔══╝  ██║╚██╗██║██║   ██║██║╚██╔╝██║
 ╚████╔╝ ███████╗██║ ╚████║╚██████╔╝██║ ╚═╝ ██║
  ╚═══╝  ╚══════╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝     ╚═╝
{Style.RESET_ALL}
{Fore.CYAN}    Subdomain Takeover Vulnerability Scanner{Style.RESET_ALL}
{Fore.YELLOW}             Version 1.0.0{Style.RESET_ALL}

"""
    print(banner)

def print_progress(current, total, item=""):
    """
    Print progress indicator.
    
    Args:
        current (int): Current progress
        total (int): Total items
        item (str): Current item being processed
    """
    if total == 0:
        return
    
    progress = (current / total) * 100
    bar_length = 50
    filled_length = int(bar_length * current // total)
    
    bar = '█' * filled_length + '-' * (bar_length - filled_length)
    
    # Truncate item name if too long
    if len(item) > 30:
        item = item[:27] + "..."
    
    print(f'\r{Fore.CYAN}[{bar}] {progress:.1f}% ({current}/{total}) {item:<30}{Style.RESET_ALL}', end='', flush=True)

def format_timestamp(timestamp):
    """
    Format timestamp for display.
    
    Args:
        timestamp (float): Unix timestamp
        
    Returns:
        str: Formatted timestamp
    """
    if not timestamp:
        return ""
    
    try:
        return datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
    except (ValueError, OSError):
        return str(timestamp)

def sanitize_filename(filename):
    """
    Sanitize filename for cross-platform compatibility.
    
    Args:
        filename (str): Original filename
        
    Returns:
        str: Sanitized filename
    """
    # Remove or replace invalid characters
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    
    # Remove leading/trailing spaces and dots
    filename = filename.strip(' .')
    
    return filename

def is_private_ip(ip):
    """
    Check if an IP address is private.
    
    Args:
        ip (str): IP address to check
        
    Returns:
        bool: True if private IP, False otherwise
    """
    import ipaddress
    
    try:
        ip_obj = ipaddress.ip_address(ip)
        return ip_obj.is_private
    except ValueError:
        return False

def get_domain_from_subdomain(subdomain):
    """
    Extract root domain from subdomain.
    
    Args:
        subdomain (str): Subdomain
        
    Returns:
        str: Root domain
    """
    parts = subdomain.split('.')
    if len(parts) >= 2:
        return '.'.join(parts[-2:])
    return subdomain

def calculate_confidence_score(indicators):
    """
    Calculate confidence score based on vulnerability indicators.
    
    Args:
        indicators (dict): Dictionary of vulnerability indicators
        
    Returns:
        str: Confidence level (high, medium, low)
    """
    score = 0
    
    # CNAME pointing to known service
    if indicators.get('cname_match', False):
        score += 3
    
    # HTTP error pattern match
    if indicators.get('http_pattern_match', False):
        score += 2
    
    # Generic error indicators
    if indicators.get('generic_error', False):
        score += 1
    
    # DNS resolution failure
    if indicators.get('dns_failure', False):
        score += 1
    
    # Determine confidence level
    if score >= 4:
        return 'high'
    elif score >= 2:
        return 'medium'
    else:
        return 'low'

def colorize_text(text, color):
    """
    Colorize text for terminal output.
    
    Args:
        text (str): Text to colorize
        color (str): Color name (red, green, yellow, cyan, etc.)
        
    Returns:
        str: Colorized text
    """
    color_map = {
        'red': Fore.RED,
        'green': Fore.GREEN,
        'yellow': Fore.YELLOW,
        'cyan': Fore.CYAN,
        'blue': Fore.BLUE,
        'magenta': Fore.MAGENTA,
        'white': Fore.WHITE
    }
    
    color_code = color_map.get(color.lower(), Fore.WHITE)
    return f"{color_code}{text}{Style.RESET_ALL}"

def truncate_string(text, max_length=50):
    """
    Truncate string to specified length.
    
    Args:
        text (str): Text to truncate
        max_length (int): Maximum length
        
    Returns:
        str: Truncated text
    """
    if not text:
        return ""
    
    if len(text) <= max_length:
        return text
    
    return text[:max_length - 3] + "..."

def parse_cname_service(cname):
    """
    Parse service name from CNAME record.
    
    Args:
        cname (str): CNAME record
        
    Returns:
        str: Service name or 'unknown'
    """
    cname_lower = cname.lower()
    
    service_patterns = {
        'aws_s3': ['.s3.amazonaws.com', '.s3-website'],
        'github': ['.github.io', '.githubusercontent.com'],
        'heroku': ['.herokuapp.com', '.herokudns.com'],
        'netlify': ['.netlify.com', '.netlify.app'],
        'surge': ['.surge.sh'],
        'firebase': ['.firebaseapp.com', '.web.app'],
        'azure': ['.azurewebsites.net', '.cloudapp.net'],
        'shopify': ['.myshopify.com'],
        'tumblr': ['.tumblr.com'],
        'wordpress': ['.wordpress.com']
    }
    
    for service, patterns in service_patterns.items():
        for pattern in patterns:
            if pattern in cname_lower:
                return service
    
    return 'unknown'

#!/usr/bin/env python3
"""
Setup script for Venom Scanner - makes installation super easy
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def print_header():
    """Print setup header"""
    print("=" * 60)
    print("    VENOM SCANNER - SUPER EASY SETUP")
    print("    No technical knowledge required!")
    print("=" * 60)
    print()

def check_python():
    """Check Python version"""
    print("🐍 Checking Python version...")
    if sys.version_info < (3, 6):
        print("❌ ERROR: You need Python 3.6 or higher")
        print("   Download Python from: https://python.org/downloads")
        return False
    
    version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    print(f"✅ Python {version} found - Perfect!")
    return True

def install_dependencies():
    """Install required packages"""
    print("\n📦 Installing required packages...")
    print("   This might take a minute...")
    
    packages = ["requests", "dnspython", "colorama"]
    
    try:
        for package in packages:
            print(f"   Installing {package}...")
            subprocess.check_call([
                sys.executable, "-m", "pip", "install", package, "--quiet"
            ])
        
        print("✅ All packages installed successfully!")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install packages: {e}")
        print("   Try running this command manually:")
        print(f"   pip install {' '.join(packages)}")
        return False

def test_installation():
    """Test if everything works"""
    print("\n🧪 Testing installation...")
    
    try:
        # Test importing all modules
        import requests
        import dns.resolver
        import colorama
        
        print("✅ All modules working!")
        
        # Test the scanner
        print("   Testing scanner...")
        result = subprocess.run([
            sys.executable, "main.py", "--help"
        ], capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0 and "Venom" in result.stdout:
            print("✅ Scanner is ready to use!")
            return True
        else:
            print("❌ Scanner test failed")
            return False
            
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False
    except subprocess.TimeoutExpired:
        print("❌ Scanner test timed out")
        return False
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

def create_shortcuts():
    """Create easy-to-use shortcuts"""
    print("\n🔗 Creating shortcuts...")
    
    # Create batch file for Windows
    if os.name == 'nt':
        batch_content = f"""@echo off
cd /d "{Path.cwd()}"
python main.py %*
pause
"""
        with open("venom.bat", "w") as f:
            f.write(batch_content)
        print("✅ Created venom.bat - double-click to run!")
    
    # Create shell script for Linux/Mac
    else:
        script_content = f"""#!/bin/bash
cd "{Path.cwd()}"
python3 main.py "$@"
"""
        with open("venom.sh", "w") as f:
            f.write(script_content)
        os.chmod("venom.sh", 0o755)
        print("✅ Created venom.sh - double-click to run!")

def print_usage_guide():
    """Print simple usage instructions"""
    print("\n" + "=" * 60)
    print("    🎉 INSTALLATION COMPLETE!")
    print("=" * 60)
    print()
    print("📋 HOW TO USE:")
    print()
    print("1. EASIEST WAY:")
    if os.name == 'nt':
        print("   • Double-click 'venom.bat'")
        print("   • Type: venom.bat -t google.com")
    else:
        print("   • Double-click 'venom.sh'") 
        print("   • Or type: ./venom.sh -t google.com")
    print()
    print("2. COMMAND LINE:")
    print("   • python main.py -t google.com")
    print()
    print("3. EXAMPLES:")
    print("   • Scan Google: python main.py -t google.com")
    print("   • Save results: python main.py -t google.com -o results.txt")
    print("   • Fast scan: python main.py -t google.com --threads 50")
    print()
    print("🔍 WHAT IT DOES:")
    print("   • Finds subdomains that could be taken over")
    print("   • Checks for vulnerable cloud services")
    print("   • Shows you security risks")
    print()
    print("⚠️  LEGAL NOTE:")
    print("   • Only scan domains you own or have permission to test")
    print("   • This tool is for security testing only")
    print()
    print("📚 For all options: python main.py --help")
    print()

def main():
    """Main setup process"""
    print_header()
    
    # Check Python
    if not check_python():
        input("Press Enter to exit...")
        return False
    
    # Install dependencies
    if not install_dependencies():
        input("Press Enter to exit...")
        return False
    
    # Test installation
    if not test_installation():
        input("Press Enter to exit...")
        return False
    
    # Create shortcuts
    create_shortcuts()
    
    # Print usage guide
    print_usage_guide()
    
    input("Press Enter to close this window...")
    return True

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n❌ Setup cancelled by user")
        input("Press Enter to exit...")
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {e}")
        input("Press Enter to exit...")